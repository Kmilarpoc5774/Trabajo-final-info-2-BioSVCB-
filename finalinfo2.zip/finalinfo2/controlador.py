import sys
import os
from pathlib import Path
import numpy as np
import cv2
import pydicom
import nibabel as nib
import matplotlib.pyplot as plt
import pandas as pd

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import (
    QApplication, QFileDialog, QMessageBox, QTableWidgetItem, QVBoxLayout, QMessageBox
)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from vista import (
    Ventana_login,
    Ventana_expertoimagenes,
    Ventana_expertosenales,
    Ventana_imagenesdicom,
    VentanaImagenesPNG,
    Ventana_senaless
)

from modelo import (
    ModeloDatos,
    ProcesadorImagenes,
    ProcesadorSenales,
    ProcesadorCSV
)

# --------------------- Controlador Principal ---------------------
from PyQt5.QtWidgets import QDialog
from PyQt5 import uic

class ControladorPrincipal:
    def __init__(self):
        self.login = Ventana_login()
        self.ventana_senales = Ventana_expertosenales()
        self.ventana_imagenes = Ventana_expertoimagenes()

        self.modelo = ModeloDatos(db_type="mongodb")
        self.procesador = ProcesadorSenales()
        self.procesador_csv = ProcesadorCSV()

        # Ventana y controlador PNG
        self.ventana_png = VentanaImagenesPNG()
        self.controlador_png = ControladorImagenesPNG(self.ventana_png)

        # Ventana y controlador DICOM
        self.ventana_dicom = Ventana_imagenesdicom()
        self.controlador_dicom = ControladorDicom(self.ventana_dicom)

        # Ventana y controlador de señales
        self.ventana_senal = Ventana_senaless()
        self.controlador_senal = ControladorVentanaSenales(
            self.ventana_senal,
            self.procesador,
            self.modelo,
            self.procesador_csv
        )

        # Conexión login
        self.login.Boton_acceder.clicked.connect(self.autenticar_usuario)

        # Conexión botones experto en imágenes
        self.ventana_imagenes.Boton_procesarimagenesj.clicked.connect(self.ventana_png.show)
        self.ventana_imagenes.Boton_cargarimagenesd.clicked.connect(self.ventana_dicom.show)
        self.ventana_imagenes.Boton_visualizarmetadatos.clicked.connect(self.abrir_metadatos)
        self.ventana_imagenes.Boton_visualizarimagenes.clicked.connect(self.abrir_imagenes_guardadas)

        # Conexión botones experto en señales
        self.ventana_senales.Boton_cargarsenales.clicked.connect(self.ventana_senal.show)
        self.ventana_senales.Boton_analizarsenales.clicked.connect(self.ventana_senal.show)
        self.ventana_senales.Boton_cargardatos.clicked.connect(self.ventana_senal.show)
        self.ventana_senales.Boton_visualizarsenales.clicked.connect(self.ventana_senal.show)

    def autenticar_usuario(self):
        usuario = self.login.usuario.toPlainText()
        contrasena = self.login.contrasena.toPlainText()
        rol = self.login.Combo_rol.currentText()

        if self.modelo.verificar_usuario(usuario, contrasena, rol):
            self.login.hide()
            if rol == "experto_senales":
                self.ventana_senales.show()
            elif rol == "experto_imagenes":
                self.ventana_imagenes.show()
        else:
            self.login.mostrar_error("Credenciales incorrectas")

    def abrir_metadatos(self):
        self.ventana_metadatos = QDialog()
        uic.loadUi("Ventana_imagenesdicom.ui", self.ventana_metadatos)
        self.ventana_metadatos.setWindowTitle("Visualización de Metadatos")
        self.ventana_metadatos.show()

    def abrir_imagenes_guardadas(self):
        self.ventana_guardadas = QDialog()
        uic.loadUi("Ventana_imagenespng2.ui", self.ventana_guardadas)
        self.ventana_guardadas.setWindowTitle("Visualización de Imágenes Anteriores")
        self.ventana_guardadas.show()

# --------------------- Controlador DICOM ---------------------
class ControladorDicom:
    def __init__(self, ventana):
        self.ventana = ventana
        self.procesador = ProcesadorImagenes()
        self.modelo = ModeloDatos(db_type='mongodb')
        self.dicom_data = None
        self.volume = None

        self.ventana.Boton_cargarcarpetad.clicked.connect(self.cargar_carpeta_dicom)
        self.ventana.Boton_convertir.clicked.connect(self.convertir_nifti)
        self.ventana.Boton_actualizar.clicked.connect(self.guardar_metadatos)
        self.ventana.Boton_guardarbd.clicked.connect(self.mostrar_metadatos)
        self.ventana.horizontalSlider.valueChanged.connect(self.actualizar_corte_axial)
        self.ventana.horizontalSlider_2.valueChanged.connect(self.actualizar_corte_coronal)
        self.ventana.horizontalSlider_3.valueChanged.connect(self.actualizar_corte_sagital)

    def cargar_carpeta_dicom(self):
        ruta = QFileDialog.getExistingDirectory(None, "Seleccionar carpeta DICOM")
        if ruta:
            try:
                archivos = [f for f in os.listdir(ruta) if f.endswith('.dcm')]
                if not archivos:
                    raise Exception("No se encontraron archivos DICOM")

                primer_archivo = pydicom.dcmread(os.path.join(ruta, archivos[0]))
                self.ventana.Label_infopac.setText(f"Paciente: {primer_archivo.PatientName}")

                slices = [pydicom.dcmread(os.path.join(ruta, f)) for f in archivos]
                slices.sort(key=lambda x: float(x.ImagePositionPatient[2]))
                self.volume = np.stack([s.pixel_array for s in slices])
                self.dicom_data = slices

                self.ventana.horizontalSlider.setRange(0, self.volume.shape[0]-1)
                self.ventana.horizontalSlider_2.setRange(0, self.volume.shape[1]-1)
                self.ventana.horizontalSlider_3.setRange(0, self.volume.shape[2]-1)

                self.actualizar_corte_axial(0)
                self.actualizar_corte_coronal(0)
                self.actualizar_corte_sagital(0)
                self.ventana.Label_ruta.setText(ruta)

            except Exception as e:
                QMessageBox.critical(self.ventana, "Error", str(e))

    def actualizar_corte_axial(self, value):
        if self.volume is not None:
            img = self.volume[value, :, :]
            self.mostrar_imagen(img, self.ventana.Label_corteaxial)

    def actualizar_corte_coronal(self, value):
        if self.volume is not None:
            img = self.volume[:, value, :]
            self.mostrar_imagen(img, self.ventana.Labelcortecoronal)

    def actualizar_corte_sagital(self, value):
        if self.volume is not None:
            img = self.volume[:, :, value]
            self.mostrar_imagen(img, self.ventana.Label_cortesagital)

    def mostrar_imagen(self, img, label):
        img = (img - img.min()) / (img.max() - img.min()) * 255
        img = img.astype(np.uint8)
        qimg = QImage(img.data, img.shape[1], img.shape[0], img.shape[1], QImage.Format_Grayscale8)
        pixmap = QPixmap.fromImage(qimg)
        label.setPixmap(pixmap.scaled(label.width(), label.height(), Qt.KeepAspectRatio))

    def convertir_nifti(self):
        if self.volume is not None:
            ruta, _ = QFileDialog.getSaveFileName(None, "Guardar como NIfTI", "", "NIfTI Files (*.nii *.nii.gz)")
            if ruta:
                img = nib.Nifti1Image(self.volume, np.eye(4))
                nib.save(img, ruta)
                self.modelo.guardar_procesamiento('nifti', os.path.basename(ruta), ruta)
                QMessageBox.information(self.ventana, "Éxito", "Conversión completada")

    def guardar_metadatos(self):
        if self.dicom_data:
            try:
                metadatos = {tag.name: str(tag.value) for tag in self.dicom_data[0] if tag.name != 'Pixel Data'}
                self.modelo.guardar_metadatos_dicom({
                    'PatientID': self.dicom_data[0].get('PatientID', ''),
                    'PatientName': str(self.dicom_data[0].get('PatientName', '')),
                    'ruta_dicom': self.ventana.Label_ruta.text(),
                    **metadatos
                })
                QMessageBox.information(self.ventana, "Éxito", "Metadatos guardados")
            except Exception as e:
                QMessageBox.critical(self.ventana, "Error", str(e))

    def mostrar_metadatos(self):
        if self.dicom_data:
            try:
                tabla = self.ventana.Tabla_metadatos  # Ajusta al nombre real del widget en tu UI
                tags = [(tag.name, str(tag.value)) for tag in self.dicom_data[0] if tag.name != 'Pixel Data']
                tabla.setRowCount(len(tags))
                tabla.setColumnCount(2)
                tabla.setHorizontalHeaderLabels(["Campo", "Valor"])

                for i, (clave, valor) in enumerate(tags):
                    tabla.setItem(i, 0, QTableWidgetItem(clave))
                    tabla.setItem(i, 1, QTableWidgetItem(valor))
            except Exception as e:
                QMessageBox.critical(self.ventana, "Error", f"No se pudieron mostrar los metadatos: {str(e)}")

# --------------------- Controlador PNG ---------------------
class ControladorImagenesPNG:
    def __init__(self, vista):
        self.vista = vista
        self.imagen_original = None
        self.imagen_modificada = None

        # Conexiones
        self.vista.Boton_abririmagen.clicked.connect(self.abrir_imagen)
        self.vista.Boton_aplicar.clicked.connect(self.aplicar_procesamiento)
        self.vista.Boton_guardar.clicked.connect(self.guardar_imagen)
        self.vista.Boton_cargarSeleccionada.clicked.connect(self.cargar_imagen_seleccionada)
        self.vista.Boton_EliminarImagen.clicked.connect(self.eliminar_imagen)

        # Opciones del combo
        self.vista.Combo_binarizacion.addItems([
            "Invertir colores",
            "Blur",
            "Morfología (erode)",
            "Morfología (dilate)"
        ])

    def abrir_imagen(self):
        ruta, _ = QFileDialog.getOpenFileName(
            None, "Abrir imagen", "", "Imágenes (*.png *.jpg *.jpeg *.bmp)"
        )
        if ruta:
            self.imagen_original = cv2.imread(ruta)
            self.mostrar_imagen(self.imagen_original, self.vista.labelOriginal)

    def aplicar_procesamiento(self):
        if self.imagen_original is None:
            QMessageBox.warning(None, "Error", "Primero debes abrir una imagen.")
            return

        opcion = self.vista.Combo_binarizacion.currentText()
        kernel_size = self.vista.spinKernel.value()
        if kernel_size % 2 == 0:
            kernel_size += 1  # debe ser impar

        try:
            if opcion == "Invertir colores":
                self.imagen_modificada = cv2.bitwise_not(self.imagen_original)
            elif opcion == "Blur":
                self.imagen_modificada = cv2.GaussianBlur(self.imagen_original, (kernel_size, kernel_size), 0)
            elif opcion == "Morfología (erode)":
                kernel = np.ones((kernel_size, kernel_size), np.uint8)
                self.imagen_modificada = cv2.erode(self.imagen_original, kernel, iterations=1)
            elif opcion == "Morfología (dilate)":
                kernel = np.ones((kernel_size, kernel_size), np.uint8)
                self.imagen_modificada = cv2.dilate(self.imagen_original, kernel, iterations=1)

            if self.imagen_modificada is None:
                raise ValueError("El procesamiento no generó una imagen válida.")

            self.mostrar_imagen(self.imagen_modificada, self.vista.label_imagen_procesada)

        except Exception as e:
            QMessageBox.critical(None, "Error de procesamiento", str(e))

    def mostrar_imagen(self, imagen_cv, label):
        height, width, channel = imagen_cv.shape
        bytes_per_line = 3 * width
        q_img = QImage(imagen_cv.data, width, height, bytes_per_line, QImage.Format_BGR888)
        pixmap = QPixmap.fromImage(q_img)
        label.setPixmap(pixmap.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def guardar_imagen(self):
        if self.imagen_modificada is None:
            QMessageBox.warning(None, "Error", "No hay imagen procesada para guardar.")
            return

        ruta, _ = QFileDialog.getSaveFileName(
            None, "Guardar imagen", "", "Imágenes PNG (*.png);;JPEG (*.jpg)"
        )

        if ruta:
            extension = os.path.splitext(ruta)[1].lower()
            if extension not in [".png", ".jpg", ".jpeg"]:
                ruta += ".png"

            try:
                cv2.imwrite(ruta, self.imagen_modificada)
                QMessageBox.information(None, "Guardado", "Imagen guardada exitosamente.")
                self.vista.listaImagenes.addItem(ruta)
            except Exception as e:
                QMessageBox.critical(None, "Error", f"No se pudo guardar:\n{str(e)}")

    def cargar_imagen_seleccionada(self):
        item = self.vista.listaImagenes.currentItem()
        if not item:
            QMessageBox.warning(None, "Advertencia", "Selecciona una imagen de la lista.")
            return

        ruta = item.text()
        if not os.path.exists(ruta):
            QMessageBox.critical(None, "Error", f"No se encontró la imagen:\n{ruta}")
            return

        pixmap = QPixmap(ruta)
        if pixmap.isNull():
            QMessageBox.critical(None, "Error", "No se pudo cargar la imagen.")
            return

        self.vista.labelVistaGuardada.setPixmap(
            pixmap.scaled(
                self.vista.labelVistaGuardada.size(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

    def eliminar_imagen(self):
        item = self.vista.listaImagenes.currentItem()
        if not item:
            QMessageBox.warning(None, "Advertencia", "Selecciona una imagen para eliminar.")
            return

        ruta = item.text()
        confirm = QMessageBox.question(
            None, "Eliminar imagen",
            f"¿Estás seguro de eliminar esta imagen?\n{ruta}",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirm == QMessageBox.Yes:
            try:
                os.remove(ruta)
                self.vista.listaImagenes.takeItem(self.vista.listaImagenes.row(item))
                self.vista.labelVistaGuardada.clear()
                QMessageBox.information(None, "Éxito", "Imagen eliminada correctamente.")
            except Exception as e:
                QMessageBox.critical(None, "Error", f"No se pudo eliminar:\n{str(e)}")


# --------------------- Controlador Señales ---------------------
class ControladorVentanaSenales:
    def __init__(self, ventana, procesador, modelo, procesador_csv):
        self.ventana = ventana
        self.procesador = procesador
        self.modelo = modelo
        self.procesador_csv = procesador_csv

        self.figura = Figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvas(self.figura)
        self.ultimo_csv = None

        
        self.ventana.Boton_cargarmat.clicked.connect(self.graficar_senal)
        self.ventana.Boton_graficarseg.clicked.connect(self.graficar_segmento)
        self.ventana.Boton_cargarcsv.clicked.connect(self.mostrar_tabla)
        self.ventana.Boton_graficardispersion.clicked.connect(self.graficar_dispersion)
        self.ventana.Boton_versenalguardada.clicked.connect(self.ver_senal_guardada)
        self.ventana.Boton_eliminarsenal.clicked.connect(self.eliminar_senal)

    def graficar_senal(self):
        try:
            archivo, _ = QFileDialog.getOpenFileName(None, "Seleccionar archivo", "", "MAT (*.mat);;CSV (*.csv)")
            if archivo:
                datos = self.procesador.cargar_datos(archivo)
                if datos is None:
                    return

                self.modelo.guardar_procesamiento("Carga señal", Path(archivo).name, archivo)

                self.figura.clear()
                ax = self.figura.add_subplot(111)

                if datos.ndim == 1:
                    ax.plot(datos)
                elif datos.ndim == 2:
                    for i in range(datos.shape[0]):
                        ax.plot(datos[i], label=f"Señal {i+1}")
                    ax.legend()

                self.canvas.draw()

                layout = self.ventana.pagina_cargarsenales.layout() or QVBoxLayout()
                self.ventana.pagina_cargarsenales.setLayout(layout)
                while layout.count():
                    item = layout.takeAt(0)
                    if item.widget(): item.widget().deleteLater()
                layout.addWidget(self.canvas)
                self.ventana.toolBox.setCurrentWidget(self.ventana.pagina_cargarsenales)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Error al graficar señal: {str(e)}")

    def graficar_segmento(self):
        try:
            archivo, _ = QFileDialog.getOpenFileName(None, "Seleccionar archivo", "", "MAT (*.mat)")
            if archivo:
                datos = self.procesador.cargar_datos(archivo)
                if datos is None:
                    return

                self.modelo.guardar_procesamiento("Segmento", Path(archivo).name, archivo)

                inicio = self.ventana.spn_inicio_segmento.value()
                longitud = self.ventana.spn_longitud_segmento.value()
                fin = inicio + longitud

                segmento = datos[inicio:fin] if datos.ndim == 1 else datos[:, inicio:fin]

                self.figura.clear()
                ax = self.figura.add_subplot(111)
                if segmento.ndim == 1:
                    ax.plot(segmento)
                else:
                    for i in range(segmento.shape[0]):
                        ax.plot(segmento[i], label=f"Segmento {i+1}")
                    ax.legend()
                self.canvas.draw()

                layout = self.ventana.pagina_analisissenales.layout() or QVBoxLayout()
                self.ventana.pagina_analisissenales.setLayout(layout)
                while layout.count():
                    item = layout.takeAt(0)
                    if item.widget(): item.widget().deleteLater()
                layout.addWidget(self.canvas)
                self.ventana.toolBox.setCurrentWidget(self.ventana.pagina_analisissenales)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Error al graficar segmento: {str(e)}")

    def mostrar_tabla(self):
        try:
            archivo, _ = QFileDialog.getOpenFileName(None, "Seleccionar CSV", "", "CSV (*.csv)")
            if not archivo:
                return
            df = self.procesador_csv.cargar_datos(archivo)
            self.modelo.guardar_procesamiento("CSV cargado", Path(archivo).name, archivo)
            self.ultimo_csv = archivo

            tabla = self.ventana.Tablacsv
            tabla.clear()
            tabla.setRowCount(len(df))
            tabla.setColumnCount(len(df.columns))
            tabla.setHorizontalHeaderLabels(df.columns.tolist())

            for i in range(len(df)):
                for j in range(len(df.columns)):
                    tabla.setItem(i, j, QTableWidgetItem(str(df.iat[i, j])))

            self.ventana.Combo_columnax.clear()
            self.ventana.Combo_columnay.clear()
            self.ventana.Combo_columnax.addItems(df.columns.tolist())
            self.ventana.Combo_columnay.addItems(df.columns.tolist())

            self.ventana.stackedWidget.setCurrentWidget(self.ventana.pagina_datostabularescsv)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Error al mostrar tabla: {str(e)}")

    def graficar_dispersion(self):
        try:
            if not self.ultimo_csv:
                QMessageBox.warning(None, "Advertencia", "Primero cargue un CSV.")
                return
            col_x = self.ventana.Combo_columnax.currentText()
            col_y = self.ventana.Combo_columnay.currentText()
            if not col_x or not col_y:
                QMessageBox.warning(None, "Advertencia", "Seleccione ambas columnas.")
                return

            df = self.procesador_csv.cargar_datos(self.ultimo_csv)
            x, y = df[col_x], df[col_y]

            self.figura.clear()
            ax = self.figura.add_subplot(111)
            ax.scatter(x, y)
            ax.set_xlabel(col_x)
            ax.set_ylabel(col_y)
            ax.set_title("Dispersión")
            self.canvas.draw()

            layout = self.ventana.pagina_datostabularescsv.layout()
            if layout:
                layout.addWidget(self.canvas)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"No se pudo graficar:\n{str(e)}")

    def mostrar_datos_anteriores(self):
        try:
            registros = self.modelo.obtener_registros()
            if not registros:
                QMessageBox.information(None, "Sin registros", "No hay señales anteriores.")
                return

            tabla = self.ventana.Tabla_senalesguardadas
            tabla.clear()
            tabla.setRowCount(len(registros))
            tabla.setColumnCount(2)
            tabla.setHorizontalHeaderLabels(["Tipo", "Archivo"])

            for i, reg in enumerate(registros):
                tabla.setItem(i, 0, QTableWidgetItem(reg.get("tipo", "")))
                tabla.setItem(i, 1, QTableWidgetItem(reg.get("archivo", "")))

            self.ventana.toolBox.setCurrentWidget(self.ventana.pagina_senalesanteriores)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"Error al mostrar registros: {str(e)}")

    def ver_senal_guardada(self):
        tabla = self.ventana.Tabla_senalesguardadas
        fila = tabla.currentRow()
        if fila == -1:
            QMessageBox.warning(None, "Advertencia", "Selecciona una fila.")
            return

        archivo = tabla.item(fila, 1).text()
        ruta = self.buscar_ruta_por_nombre(archivo)
        if not ruta or not os.path.exists(ruta):
            QMessageBox.critical(None, "Error", "Archivo no encontrado.")
            return

        try:
            datos = self.procesador.cargar_datos(ruta)
            self.figura.clear()
            ax = self.figura.add_subplot(111)
            if datos.ndim == 1:
                ax.plot(datos)
            else:
                for i in range(datos.shape[0]):
                    ax.plot(datos[i], label=f"Señal {i+1}")
                ax.legend()
            self.canvas.draw()

            layout = self.ventana.pagina_senalesanteriores.layout() or QVBoxLayout()
            self.ventana.pagina_senalesanteriores.setLayout(layout)
            while layout.count():
                item = layout.takeAt(0)
                if item.widget(): item.widget().deleteLater()
            layout.addWidget(self.canvas)
        except Exception as e:
            QMessageBox.critical(None, "Error", f"No se pudo cargar la señal: {str(e)}")

    def eliminar_senal(self):
        tabla = self.ventana.Tabla_senalesguardadas
        fila = tabla.currentRow()
        if fila == -1:
            QMessageBox.warning(None, "Advertencia", "Selecciona una señal.")
            return

        archivo = tabla.item(fila, 1).text()
        confirm = QMessageBox.question(None, "Confirmar", f"¿Eliminar '{archivo}'?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            exito = self.modelo.eliminar_archivo(archivo)
            if exito:
                QMessageBox.information(None, "Eliminado", f"'{archivo}' fue eliminado.")
                self.mostrar_datos_anteriores()
            else:
                QMessageBox.critical(None, "Error", "No se pudo eliminar el archivo.")

    def buscar_ruta_por_nombre(self, nombre):
        return self.modelo.obtener_ruta_por_nombre(nombre)



# --------------------- Main ---------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    controlador = ControladorPrincipal()
    controlador.login.show()
    sys.exit(app.exec_())
